ALTER TABLE `#__agoms_details` ADD COLUMN  `params` text NOT NULL AFTER `alias`;
