DROP TABLE IF EXISTS `#__agosms_details`;
